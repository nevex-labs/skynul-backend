export const systemKeys = {
  runtime: ['system', 'runtime'] as const,
  snapshots: ['system', 'snapshots'] as const,
};

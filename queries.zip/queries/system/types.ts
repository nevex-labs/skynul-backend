export type RuntimeStats = {
  app: {
    cpuPercent: number;
    memoryMB: number;
  };
  system: {
    freeMemMB: number;
  };
};

export type BrowserSnapshot = {
  id: string;
  name: string;
  url: string;
  title: string;
  createdAt: number;
};

import { useMutation, useQuery, useQueryClient, type UseMutationOptions, type UseQueryOptions } from '@tanstack/react-query';
import type { ApiError } from '../client';
import { systemKeys } from './keys';
import { systemService } from './service';
import type { BrowserSnapshot, RuntimeStats } from './types';

export function useRuntimeStats(opts?: Omit<UseQueryOptions<RuntimeStats, ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({
    queryKey: systemKeys.runtime,
    queryFn: systemService.runtime,
    refetchInterval: 5000,
    ...opts,
  });
}

export function useBrowserSnapshots(opts?: Omit<UseQueryOptions<BrowserSnapshot[], ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: systemKeys.snapshots, queryFn: systemService.snapshots.list, ...opts });
}

export function useSaveBrowserSnapshot(opts?: UseMutationOptions<{ ok: true }, ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: systemService.snapshots.save,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: systemKeys.snapshots });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useRestoreBrowserSnapshot(opts?: UseMutationOptions<{ ok: true }, ApiError, string>) {
  return useMutation({ mutationFn: systemService.snapshots.restore, ...opts });
}

export function useDeleteBrowserSnapshot(opts?: UseMutationOptions<{ ok: true }, ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: systemService.snapshots.delete,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: systemKeys.snapshots });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

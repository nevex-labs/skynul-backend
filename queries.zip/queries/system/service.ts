import { api } from '../client';
import type { BrowserSnapshot, RuntimeStats } from './types';

export const systemService = {
  runtime: () => api<RuntimeStats>('/api/system/runtime/stats'),

  snapshots: {
    list: () => api<BrowserSnapshot[]>('/api/system/browser/snapshots'),

    save: (name: string) =>
      api<{ ok: true }>('/api/system/browser/snapshots', {
        method: 'POST',
        body: JSON.stringify({ name }),
      }),

    restore: (id: string) =>
      api<{ ok: true }>(`/api/system/browser/snapshots/${id}/restore`, { method: 'POST' }),

    delete: (id: string) =>
      api<{ ok: true }>(`/api/system/browser/snapshots/${id}`, { method: 'DELETE' }),
  },
};

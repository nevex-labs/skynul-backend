import { useMutation, useQuery, useQueryClient, type UseMutationOptions, type UseQueryOptions } from '@tanstack/react-query';
import type { ApiError } from '../client';
import { skillKeys } from './keys';
import { skillService } from './service';
import type { Skill, SkillSaveRequest } from './types';

export function useSkills(opts?: Omit<UseQueryOptions<Skill[], ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: skillKeys.all, queryFn: skillService.list, ...opts });
}

export function useSaveSkill(opts?: UseMutationOptions<Skill[], ApiError, SkillSaveRequest>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: skillService.save,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: skillKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useDeleteSkill(opts?: UseMutationOptions<Skill[], ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: skillService.delete,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: skillKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useToggleSkill(opts?: UseMutationOptions<Skill[], ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: skillService.toggle,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: skillKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useImportSkill(opts?: UseMutationOptions<Skill[], ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: skillService.import,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: skillKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

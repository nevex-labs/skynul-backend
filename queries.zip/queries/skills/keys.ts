export const skillKeys = {
  all: ['skills'] as const,
};

import { api } from '../client';
import type { Skill, SkillSaveRequest } from './types';

export const skillService = {
  list: () => api<{ skills: Skill[] }>('/api/agent/skills').then((r) => r.skills),

  save: (body: SkillSaveRequest) =>
    api<{ skills: Skill[] }>('/api/agent/skills', {
      method: 'POST',
      body: JSON.stringify(body),
    }).then((r) => r.skills),

  delete: (id: string) =>
    api<{ skills: Skill[] }>(`/api/agent/skills/${id}`, { method: 'DELETE' }).then((r) => r.skills),

  toggle: (id: string) =>
    api<{ skills: Skill[] }>(`/api/agent/skills/${id}/toggle`, { method: 'PUT' }).then((r) => r.skills),

  import: (filePath: string) =>
    api<{ skills: Skill[] }>('/api/agent/skills/import', {
      method: 'POST',
      body: JSON.stringify({ filePath }),
    }).then((r) => r.skills),
};

import { useMutation, type UseMutationOptions } from '@tanstack/react-query';
import type { ApiError } from '../client';
import { chatService } from './service';
import type { ChatMessage } from './types';

export function useSendChat(opts?: UseMutationOptions<string, ApiError, ChatMessage[]>) {
  return useMutation({ mutationFn: chatService.send, ...opts });
}

import { api } from '../client';
import type { ChatMessage } from './types';

export const chatService = {
  send: (messages: ChatMessage[]) =>
    api<{ content: string }>('/api/ai/chat/send', {
      method: 'POST',
      body: JSON.stringify({ messages }),
    }).then((r) => r.content),
};

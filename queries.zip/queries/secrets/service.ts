import { api } from '../client';

export const secretService = {
  keys: () => api<{ keys: string[] }>('/api/integrations/secrets/keys').then((r) => r.keys),

  get: (key: string) =>
    api<{ value: string | null }>(`/api/integrations/secrets/${key}`).then((r) => r.value),

  set: (key: string, value: string) =>
    api<{ ok: true }>(`/api/integrations/secrets/${key}`, {
      method: 'PUT',
      body: JSON.stringify({ value }),
    }),

  exists: (key: string) =>
    api<{ exists: boolean }>(`/api/integrations/secrets/${key}/exists`).then((r) => r.exists),
};

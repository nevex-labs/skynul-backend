import { useMutation, useQuery, useQueryClient, type UseMutationOptions, type UseQueryOptions } from '@tanstack/react-query';
import type { ApiError } from '../client';
import { secretKeys } from './keys';
import { secretService } from './service';

export function useSecretKeys(opts?: Omit<UseQueryOptions<string[], ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: secretKeys.keys, queryFn: secretService.keys, ...opts });
}

export function useSecret(key: string, opts?: Omit<UseQueryOptions<string | null, ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: secretKeys.value(key), queryFn: () => secretService.get(key), ...opts });
}

export function useSetSecret(opts?: UseMutationOptions<{ ok: true }, ApiError, { key: string; value: string }>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ key, value }) => secretService.set(key, value),
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: secretKeys.keys });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSecretExists(key: string, opts?: Omit<UseQueryOptions<boolean, ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: secretKeys.exists(key), queryFn: () => secretService.exists(key), ...opts });
}

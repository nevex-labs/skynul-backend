export type SecretKeysResponse = {
  keys: string[];
};

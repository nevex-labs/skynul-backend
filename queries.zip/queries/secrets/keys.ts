export const secretKeys = {
  keys: ['secrets', 'keys'] as const,
  value: (key: string) => ['secrets', key] as const,
  exists: (key: string) => ['secrets', key, 'exists'] as const,
};

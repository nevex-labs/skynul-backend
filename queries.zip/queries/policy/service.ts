import { api } from '../client';
import type { CapabilityId, LanguageCode, PolicyState, ProviderId, ThemeMode } from './types';

export const policyService = {
  get: () => api<PolicyState>('/api/agent/policy'),

  setCapability: (id: CapabilityId, enabled: boolean) =>
    api<PolicyState>('/api/agent/policy/capability', {
      method: 'PUT',
      body: JSON.stringify({ id, enabled }),
    }),

  setTheme: (themeMode: ThemeMode) =>
    api<PolicyState>('/api/agent/policy/theme', {
      method: 'PUT',
      body: JSON.stringify({ themeMode }),
    }),

  setLanguage: (language: LanguageCode) =>
    api<PolicyState>('/api/agent/policy/language', {
      method: 'PUT',
      body: JSON.stringify({ language }),
    }),

  setProvider: (active: ProviderId) =>
    api<PolicyState>('/api/agent/policy/provider', {
      method: 'PUT',
      body: JSON.stringify({ active }),
    }),

  setModel: (model: string) =>
    api<PolicyState>('/api/agent/policy/provider/model', {
      method: 'PUT',
      body: JSON.stringify({ model }),
    }),

  setTaskMemory: (enabled: boolean) =>
    api<PolicyState>('/api/agent/policy/task-memory', {
      method: 'PUT',
      body: JSON.stringify({ enabled }),
    }),

  setTaskAutoApprove: (enabled: boolean) =>
    api<PolicyState>('/api/agent/policy/task-auto-approve', {
      method: 'PUT',
      body: JSON.stringify({ enabled }),
    }),

  setWorkspace: (path: string | null) =>
    api<PolicyState>('/api/agent/policy/workspace', {
      method: 'PUT',
      body: JSON.stringify({ path }),
    }),
};

import { useMutation, useQuery, useQueryClient, type UseMutationOptions, type UseQueryOptions } from '@tanstack/react-query';
import type { ApiError } from '../client';
import { policyKeys } from './keys';
import { policyService } from './service';
import type { CapabilityId, LanguageCode, PolicyState, ProviderId, ThemeMode } from './types';

export function usePolicy(opts?: Omit<UseQueryOptions<PolicyState, ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: policyKeys.current, queryFn: policyService.get, ...opts });
}

export function useSetCapability(opts?: UseMutationOptions<PolicyState, ApiError, { id: CapabilityId; enabled: boolean }>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, enabled }) => policyService.setCapability(id, enabled),
    onSuccess: (data, ...rest) => {
      qc.setQueryData(policyKeys.current, data);
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSetTheme(opts?: UseMutationOptions<PolicyState, ApiError, ThemeMode>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: policyService.setTheme,
    onSuccess: (data, ...rest) => {
      qc.setQueryData(policyKeys.current, data);
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSetLanguage(opts?: UseMutationOptions<PolicyState, ApiError, LanguageCode>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: policyService.setLanguage,
    onSuccess: (data, ...rest) => {
      qc.setQueryData(policyKeys.current, data);
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSetProvider(opts?: UseMutationOptions<PolicyState, ApiError, ProviderId>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: policyService.setProvider,
    onSuccess: (data, ...rest) => {
      qc.setQueryData(policyKeys.current, data);
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSetModel(opts?: UseMutationOptions<PolicyState, ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: policyService.setModel,
    onSuccess: (data, ...rest) => {
      qc.setQueryData(policyKeys.current, data);
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSetTaskMemory(opts?: UseMutationOptions<PolicyState, ApiError, boolean>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: policyService.setTaskMemory,
    onSuccess: (data, ...rest) => {
      qc.setQueryData(policyKeys.current, data);
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSetTaskAutoApprove(opts?: UseMutationOptions<PolicyState, ApiError, boolean>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: policyService.setTaskAutoApprove,
    onSuccess: (data, ...rest) => {
      qc.setQueryData(policyKeys.current, data);
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSetWorkspace(opts?: UseMutationOptions<PolicyState, ApiError, string | null>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: policyService.setWorkspace,
    onSuccess: (data, ...rest) => {
      qc.setQueryData(policyKeys.current, data);
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

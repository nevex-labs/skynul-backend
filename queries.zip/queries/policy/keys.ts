export const policyKeys = {
  current: ['policy'] as const,
};

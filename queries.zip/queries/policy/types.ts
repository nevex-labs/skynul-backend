export type CapabilityId = 'fs.read' | 'fs.write' | 'cmd.run' | 'net.http';

export type LanguageCode = 'en' | 'es';

export type ThemeMode = 'system' | 'light' | 'dark';

export type ProviderId =
  | 'chatgpt'
  | 'claude'
  | 'deepseek'
  | 'kimi'
  | 'glm'
  | 'minimax'
  | 'openrouter'
  | 'gemini'
  | 'ollama';

export type PolicyState = {
  workspaceRoot: string | null;
  capabilities: Record<CapabilityId, boolean>;
  themeMode: ThemeMode;
  language: LanguageCode;
  provider: {
    active: ProviderId;
    openaiModel: string;
  };
  taskMemoryEnabled: boolean;
  taskAutoApprove: boolean;
};

import { api } from '../client';
import type { Project } from './types';

export const projectService = {
  list: () => api<{ projects: Project[] }>('/api/tasks/projects').then((r) => r.projects),

  create: (name: string, color?: string) =>
    api<Project>('/api/tasks/projects', {
      method: 'POST',
      body: JSON.stringify({ name, color }),
    }),

  update: (id: string, name: string, color: string) =>
    api<{ ok: true }>(`/api/tasks/projects/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ name, color }),
    }),

  delete: (id: string) => api<{ ok: true }>(`/api/tasks/projects/${id}`, { method: 'DELETE' }),

  addTask: (projectId: string, taskId: string) =>
    api<{ ok: true }>(`/api/tasks/projects/${projectId}/tasks/${taskId}`, { method: 'POST' }),

  removeTask: (projectId: string, taskId: string) =>
    api<{ ok: true }>(`/api/tasks/projects/${projectId}/tasks/${taskId}`, { method: 'DELETE' }),
};

import { useMutation, useQuery, useQueryClient, type UseMutationOptions, type UseQueryOptions } from '@tanstack/react-query';
import type { ApiError } from '../client';
import { projectKeys } from './keys';
import { projectService } from './service';
import type { Project } from './types';

export function useProjects(opts?: Omit<UseQueryOptions<Project[], ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: projectKeys.all, queryFn: projectService.list, ...opts });
}

export function useCreateProject(opts?: UseMutationOptions<Project, ApiError, { name: string; color?: string }>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ name, color }) => projectService.create(name, color),
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: projectKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useUpdateProject(opts?: UseMutationOptions<{ ok: true }, ApiError, { id: string; name: string; color: string }>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, name, color }) => projectService.update(id, name, color),
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: projectKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useDeleteProject(opts?: UseMutationOptions<{ ok: true }, ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: projectService.delete,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: projectKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useProjectAddTask(opts?: UseMutationOptions<{ ok: true }, ApiError, { projectId: string; taskId: string }>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ projectId, taskId }) => projectService.addTask(projectId, taskId),
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: projectKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useProjectRemoveTask(opts?: UseMutationOptions<{ ok: true }, ApiError, { projectId: string; taskId: string }>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ projectId, taskId }) => projectService.removeTask(projectId, taskId),
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: projectKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

let baseUrl = import.meta.env.VITE_API_URL ?? 'http://localhost:3141';
let authToken: string | null = null;

export function configure(opts: { baseUrl?: string; token?: string }) {
  if (opts.baseUrl) baseUrl = opts.baseUrl.replace(/\/$/, '');
  if (opts.token !== undefined) authToken = opts.token;
}

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(init?.headers as Record<string, string>),
  };

  if (authToken) {
    headers.Authorization = `Bearer ${authToken}`;
  }

  const res = await fetch(`${baseUrl}${path}`, { ...init, headers });

  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }));
    throw new ApiError(res.status, (body as { error?: string }).error ?? res.statusText);
  }

  return res.json() as Promise<T>;
}

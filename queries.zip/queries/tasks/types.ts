export type TaskCapabilityId =
  | 'browser.cdp'
  | 'app.launch'
  | 'polymarket.trading'
  | 'office.professional'
  | 'app.scripting';

export type TaskStatus = 'pending_approval' | 'approved' | 'running' | 'completed' | 'failed' | 'cancelled';

export type TaskMode = 'browser' | 'code';

export type TaskSource = 'desktop' | 'telegram' | 'discord' | 'slack' | 'whatsapp' | 'signal';

export type TaskAction =
  | { type: 'click'; x: number; y: number; button?: 'left' | 'right' | 'middle' }
  | { type: 'double_click'; x: number; y: number }
  | { type: 'type'; text: string }
  | { type: 'key'; combo: string }
  | { type: 'scroll'; x: number; y: number; direction: 'up' | 'down'; amount?: number }
  | { type: 'move'; x: number; y: number }
  | { type: 'launch'; app: string }
  | { type: 'wait'; ms: number }
  | { type: 'web_scrape'; url: string; instruction: string }
  | { type: 'save_to_excel'; filename: string; filter?: string }
  | { type: 'shell'; command: string; cwd?: string; timeout?: number }
  | { type: 'upload_file'; selector: string; filePaths: string[] }
  | { type: 'done'; summary: string }
  | { type: 'fail'; reason: string }
  | { type: 'user_message'; text: string }
  | { type: 'polymarket_get_account_summary' }
  | { type: 'polymarket_get_trader_leaderboard' }
  | { type: 'polymarket_search_markets'; query: string; limit?: number }
  | { type: 'polymarket_place_order'; tokenId: string; side: 'buy' | 'sell'; price: number; size: number; tickSize?: string; negRisk?: boolean }
  | { type: 'polymarket_close_position'; tokenId: string; size?: number }
  | { type: 'file_read'; path: string; offset?: number; limit?: number; cwd?: string }
  | { type: 'file_write'; path: string; content: string; cwd?: string }
  | { type: 'file_edit'; path: string; old_string: string; new_string: string; cwd?: string }
  | { type: 'file_list'; pattern: string; cwd?: string }
  | { type: 'file_search'; pattern: string; path?: string; glob?: string; cwd?: string }
  | { type: 'task_list_peers' }
  | { type: 'task_send'; prompt: string; agentName?: string; agentRole?: string }
  | { type: 'task_read'; taskId: string }
  | { type: 'task_message'; taskId: string; message: string }
  | { type: 'app_script'; app: string; script: string }
  | { type: 'remember_fact'; fact: string }
  | { type: 'forget_fact'; factId: number }
  | { type: 'set_identity'; name: string; role?: string }
  | { type: 'generate_image'; prompt: string; size?: '1024x1024' | '1792x1024' | '1024x1792' };

export type TaskStep = {
  index: number;
  timestamp: number;
  screenshotBase64: string;
  action: TaskAction;
  thought?: string;
  result?: string;
  error?: string;
};

export type Task = {
  id: string;
  parentTaskId?: string;
  agentName?: string;
  agentRole?: string;
  prompt: string;
  attachments?: string[];
  status: TaskStatus;
  mode: TaskMode;
  capabilities: TaskCapabilityId[];
  steps: TaskStep[];
  usage?: { inputTokens: number; outputTokens: number };
  createdAt: number;
  updatedAt: number;
  maxSteps: number;
  timeoutMs: number;
  error?: string;
  summary?: string;
  source?: TaskSource;
};

export type TaskCreateRequest = {
  prompt: string;
  capabilities: TaskCapabilityId[];
  attachments?: string[];
  mode?: TaskMode;
  maxSteps?: number;
  timeoutMs?: number;
  source?: TaskSource;
  parentTaskId?: string;
  agentName?: string;
  agentRole?: string;
};

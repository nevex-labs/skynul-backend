import { api } from '../client';
import type { Task, TaskCreateRequest } from './types';

export const taskService = {
  list: () => api<{ tasks: Task[] }>('/api/tasks').then((r) => r.tasks),

  get: (id: string) => api<Task>(`/api/tasks/${id}`),

  create: (body: TaskCreateRequest) =>
    api<{ task: Task }>('/api/tasks', {
      method: 'POST',
      body: JSON.stringify(body),
    }).then((r) => r.task),

  approve: (id: string) =>
    api<{ task: Task }>(`/api/tasks/${id}/approve`, { method: 'POST' }).then((r) => r.task),

  cancel: (id: string) =>
    api<{ task: Task }>(`/api/tasks/${id}/cancel`, { method: 'POST' }).then((r) => r.task),

  delete: (id: string) => api<{ ok: true }>(`/api/tasks/${id}`, { method: 'DELETE' }),

  sendMessage: (id: string, message: string) =>
    api<{ ok: true }>(`/api/tasks/${id}/message`, {
      method: 'POST',
      body: JSON.stringify({ message }),
    }),
};

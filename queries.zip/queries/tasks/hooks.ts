import { useMutation, useQuery, useQueryClient, type UseMutationOptions, type UseQueryOptions } from '@tanstack/react-query';
import type { ApiError } from '../client';
import { taskKeys } from './keys';
import { taskService } from './service';
import type { Task, TaskCreateRequest } from './types';

export function useTasks(opts?: Omit<UseQueryOptions<Task[], ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: taskKeys.all, queryFn: taskService.list, ...opts });
}

export function useTask(id: string, opts?: Omit<UseQueryOptions<Task, ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: taskKeys.detail(id), queryFn: () => taskService.get(id), ...opts });
}

export function useCreateTask(opts?: UseMutationOptions<Task, ApiError, TaskCreateRequest>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: taskService.create,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: taskKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useApproveTask(opts?: UseMutationOptions<Task, ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: taskService.approve,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: taskKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useCancelTask(opts?: UseMutationOptions<Task, ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: taskService.cancel,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: taskKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useDeleteTask(opts?: UseMutationOptions<{ ok: true }, ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: taskService.delete,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: taskKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSendTaskMessage(opts?: UseMutationOptions<{ ok: true }, ApiError, { id: string; message: string }>) {
  return useMutation({
    mutationFn: ({ id, message }) => taskService.sendMessage(id, message),
    ...opts,
  });
}

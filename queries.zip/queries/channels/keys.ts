export const channelKeys = {
  all: ['channels'] as const,
  global: ['channels', 'global'] as const,
};

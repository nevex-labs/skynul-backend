import { useMutation, useQuery, useQueryClient, type UseMutationOptions, type UseQueryOptions } from '@tanstack/react-query';
import type { ApiError } from '../client';
import { channelKeys } from './keys';
import { channelService } from './service';
import type { ChannelGlobalSettings, ChannelId, ChannelSettings } from './types';

export function useChannels(opts?: Omit<UseQueryOptions<ChannelSettings[], ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: channelKeys.all, queryFn: channelService.list, ...opts });
}

export function useChannelGlobal(opts?: Omit<UseQueryOptions<ChannelGlobalSettings, ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: channelKeys.global, queryFn: channelService.getGlobal, ...opts });
}

export function useSetChannelEnabled(opts?: UseMutationOptions<ChannelSettings, ApiError, { id: ChannelId; enabled: boolean }>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, enabled }) => channelService.setEnabled(id, enabled),
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: channelKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSetChannelCredentials(opts?: UseMutationOptions<{ ok: true }, ApiError, { id: ChannelId; credentials: Record<string, string> }>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, credentials }) => channelService.setCredentials(id, credentials),
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: channelKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useGeneratePairing(opts?: UseMutationOptions<{ code: string }, ApiError, ChannelId>) {
  return useMutation({ mutationFn: channelService.generatePairing, ...opts });
}

export function useUnpairChannel(opts?: UseMutationOptions<{ ok: true }, ApiError, ChannelId>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: channelService.unpair,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: channelKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useSetChannelAutoApprove(opts?: UseMutationOptions<ChannelGlobalSettings, ApiError, boolean>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: channelService.setAutoApprove,
    onSuccess: (data, ...rest) => {
      qc.setQueryData(channelKeys.global, data);
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

import { api } from '../client';
import type { ChannelGlobalSettings, ChannelId, ChannelSettings } from './types';

export const channelService = {
  list: () =>
    api<{ channels: ChannelSettings[] }>('/api/integrations/channels').then((r) => r.channels),

  getGlobal: () => api<ChannelGlobalSettings>('/api/integrations/channels/global'),

  setEnabled: (id: ChannelId, enabled: boolean) =>
    api<ChannelSettings>(`/api/integrations/channels/${id}/enabled`, {
      method: 'PUT',
      body: JSON.stringify({ enabled }),
    }),

  setCredentials: (id: ChannelId, credentials: Record<string, string>) =>
    api<{ ok: true }>(`/api/integrations/channels/${id}/credentials`, {
      method: 'PUT',
      body: JSON.stringify(credentials),
    }),

  generatePairing: (id: ChannelId) =>
    api<{ code: string }>(`/api/integrations/channels/${id}/pairing`, { method: 'POST' }),

  unpair: (id: ChannelId) =>
    api<{ ok: true }>(`/api/integrations/channels/${id}/pairing`, { method: 'DELETE' }),

  setAutoApprove: (enabled: boolean) =>
    api<ChannelGlobalSettings>('/api/integrations/channels/auto-approve', {
      method: 'PUT',
      body: JSON.stringify({ enabled }),
    }),
};

import { useMutation, useQuery, useQueryClient, type UseMutationOptions, type UseQueryOptions } from '@tanstack/react-query';
import type { ApiError } from '../client';
import { scheduleKeys } from './keys';
import { scheduleService } from './service';
import type { Schedule, ScheduleSaveRequest } from './types';

export function useSchedules(opts?: Omit<UseQueryOptions<Schedule[], ApiError>, 'queryKey' | 'queryFn'>) {
  return useQuery({ queryKey: scheduleKeys.all, queryFn: scheduleService.list, ...opts });
}

export function useSaveSchedule(opts?: UseMutationOptions<Schedule[], ApiError, ScheduleSaveRequest>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: scheduleService.save,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: scheduleKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useDeleteSchedule(opts?: UseMutationOptions<Schedule[], ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: scheduleService.delete,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: scheduleKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

export function useToggleSchedule(opts?: UseMutationOptions<Schedule[], ApiError, string>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: scheduleService.toggle,
    onSuccess: (data, ...rest) => {
      qc.invalidateQueries({ queryKey: scheduleKeys.all });
      opts?.onSuccess?.(data, ...rest);
    },
    ...opts,
  });
}

import { api } from '../client';
import type { Schedule, ScheduleSaveRequest } from './types';

export const scheduleService = {
  list: () => api<{ schedules: Schedule[] }>('/api/tasks/schedules').then((r) => r.schedules),

  save: (body: ScheduleSaveRequest) =>
    api<{ schedules: Schedule[] }>('/api/tasks/schedules', {
      method: 'POST',
      body: JSON.stringify(body),
    }).then((r) => r.schedules),

  delete: (id: string) =>
    api<{ schedules: Schedule[] }>(`/api/tasks/schedules/${id}`, { method: 'DELETE' }).then((r) => r.schedules),

  toggle: (id: string) =>
    api<{ schedules: Schedule[] }>(`/api/tasks/schedules/${id}/toggle`, { method: 'PUT' }).then((r) => r.schedules),
};

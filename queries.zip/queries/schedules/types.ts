import type { TaskCapabilityId, TaskMode } from '../tasks/types';

export type ScheduleFrequency = 'daily' | 'weekly' | 'custom';

export type Schedule = {
  id: string;
  prompt: string;
  capabilities: TaskCapabilityId[];
  mode: TaskMode;
  frequency: ScheduleFrequency;
  cronExpr: string;
  enabled: boolean;
  lastRunAt: number | null;
  nextRunAt: number;
  createdAt: number;
};

export type ScheduleSaveRequest = {
  id?: string;
  prompt: string;
  capabilities: string[];
  mode: TaskMode;
  frequency: ScheduleFrequency;
  cronExpr: string;
  enabled?: boolean;
};

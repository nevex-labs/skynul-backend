export const scheduleKeys = {
  all: ['schedules'] as const,
};
